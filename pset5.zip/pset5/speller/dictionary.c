#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdbool.h>
#include <strings.h>

#include "dictionary.h"

typedef struct node
{
    char w[LENGTH + 1];
    struct node *next;
}
node;

const unsigned int N = 65536;


node *table[N];

unsigned int word_count = 0;

// Returns true if word is in dictionary else false
bool check(const char *word)
{
    // TODO
    int a = strlen(word);
    char b[a + 1];

    for (int x = 0; x < a; x++)
    {
        b[x] = tolower(word[x]);
    }
    b[a] = '\0';
    node *cursor = table[hash(b)];
    if (a == 1)
    {
        return true;
    }
    while (cursor != NULL)
    {
        if (strcasecmp(word, cursor->w) == 0)
        {
            return true;
        }
        cursor = cursor->next;
    }

    return false;
}

unsigned int hash(const char *word)
{
    // TODO
    unsigned int c = 0;
    for (int x = 0, y = strlen(word); x < y; x++)
    {
        c = (c << 2) ^ word[x];
    }
    return c % N;
}
bool load(const char *dictionary)
{
    // TODO
    char d[LENGTH + 1];
    FILE *dictionary_file = fopen(dictionary, "r");
    while (fscanf(dictionary_file, "%s", d) != EOF)
    {
        node *word_node = malloc(sizeof(node));
        if (word_node == NULL)
        {
            unload();
            // return the false
            return false;
        }
        else
        {
            strcpy(word_node->w, d);
            // int e hash word
            int e = hash(word_node->w);

            word_node->next = table[e];

            table[e] = word_node;
            word_count++;
        }
    }
    fclose(dictionary_file);
    return true;
}
// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    return word_count;
}
bool unload(void)
{
    // TODO
    for (int x = 0; x < N; x++)
    {
        node *cursor = table[x];
        while (cursor != NULL)
        {
            node *temp = cursor;
            cursor = cursor -> next;
            free(temp);
        }
        free(cursor);
    }
    return true;
}