from cs50 import*

# get user input
while True:
    a = get_float("Change owed: ")
    if a > 0:
        break          # stop loop

# de va
b = a * 100
c = 0
d = [25, 10, 5, 1]

# calculate coins
for q in d:
    while b >= q:
        b -= q
        c += 1

# print output for uaser
print(f"{c}")