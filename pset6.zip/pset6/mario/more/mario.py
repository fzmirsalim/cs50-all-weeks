# library that we need
from cs50 import*

# make while loop
while True:
    # get user input
    a = get_int("Height: ")
    tool = a
    if a > 0 and a <= 8:
        break
# make for loop
for x in range(1, a + 1):
    if a == 0:
        print()
    b = x
    c = tool - b
    print(" " * c, end="")
    print("#" * b, end="")
    print("  ", end="")
    print("#" * b)