# this is my hello program
# for cs50

# get user input
a = input("What is your name?\n")

# say hello to user
print(f"hello, {a}")