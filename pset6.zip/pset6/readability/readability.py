# readability program
from cs50 import*

# make funktion


def done():
    while True:
        string = cs50.get_string('Text: ')

        # our variable
        a = 0
        i = 0
        c = 0
        d = 0
        aa = 0
        b = 1
        cc = 0

        if string:
            for n in range(len(string)):
                if string[n].isalpha():
                    c += 1

                elif string[n].isdigit():
                    d += 1

                elif string[n] == ' ' and string[i + 1]:
                    b += 1

                elif string[n] == '?' or string[n] == '!' or string[n] == '.':
                    cc += 1

                else:
                    aa += 1

            q = float(c / b * 100)

            q1 = float(cc / b * 100)

            # our readbility
            a = round((float)(0.0588 * q - 0.296 * q1 - 15.8))

            # show our output to user
            if a >= 16:
                print('Grade 16+')

            elif a < 1:
                print('Before Grade 1')

            else:
                print('Grade ', a)

            break


done()