# library we need
import csv
import sys

# make funk


def repeats(str, dna):
    """ do almost main things """
    a = []
    b = 0
    c = 0
    while c < len(dna):
        if dna[c: c + len(str)] == str:
            b = b + 1
            c = c + len(str)
            continue
        elif b > 0:
            a.append(b)
            b = 0
        c = c + 1

    if not a:
        return 0
    else:
        return max(a)


e = sys.argv[1]
f = []
with open(e) as file:
    reader = csv.reader(file)
    for each in reader:
        f.append(each)
gh = sys.argv[2]
with open(gh) as file:
    dna = file.read()
co = True
for i in range(1, len(f)):
    for j in range(1, len(f[0])):
        if int(f[i][j]) != repeats(f[0][j], dna):
            co = False
            break
        else:
            co = True

    if co == True:
        print(f[i][0])
        sys.exit(0)
print("No match")