#include <cs50.h>
#include <stdio.h>

int main()
{
    char* s = "BAW";
    printf("%c\n", s[0]); 
    printf("%c\n", s[1]);
}
