#include <stdio.h>

int main()
{
    int n = 50;
    int* p = &n;   //pointer , esharegar //int* is valiable esharegar
    printf("%p\n", *&p); // %p , %i
}


