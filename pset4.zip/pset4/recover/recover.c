#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <stdint.h>
#include <stdlib.h>

typedef uint8_t byte;
bool E(byte *bb);

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        fprintf(stderr, "Usage: recover forensicfilename.raw\n");
        return 1;
    }
    // here we open our file
    FILE *inptr = fopen(argv[1], "r");
    if (inptr == NULL)
    {
        fprintf(stderr, "Could not open %s.\n", argv[1]);
        return 2;
    }
    FILE *JPG;
    byte bb[512];

    bool a = false;
    int c = 0;

    while (fread(bb, sizeof(bb), 1, inptr) == 1)
    {
        if (E(bb))
        {
            char d[8];
            sprintf(d, "%03.3i.jpg", c);
            printf("processing file: %s\n", d);

            if (a == true)
            {
                fclose(JPG);
            }
            else
            {
                a = true;
            }

            JPG = fopen(d, "w");
            fwrite(bb, sizeof(bb), 1, JPG);
            c++;
        }
        else
        {
            if (a == true)
            {
                fwrite(bb, sizeof(bb), 1, JPG);
            }
        }
    }
    fclose(inptr);
    fclose(JPG);
}

bool E(byte *bb)
{
    if (bb[0] == 0xff &&
        bb[1] == 0xd8 &&
        bb[2] == 0xff &&
        (bb[3] & 0xf0) == 0xe0)
    {
        return true;
    }
    else
    {
        return false;
    }
}