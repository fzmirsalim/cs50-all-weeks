#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // TODO: Prompt for start size
    int a;
    do
    {
        a = get_int("Start size: ");
    }
    while (a < 9);

    // TODO: Prompt for end size
    int b;
    do
    {
        b = get_int("End size: ");
    }
    while (b < a);

    // keep track of number of years
    int Y = 0;

    // TODO: Calculate number of years until we reach threshold
    while (a < b)
    {
        a = a + (a / 3) - (a / 4);
        Y++;
    }

    // TODO: Print number of years
    printf("Years: %i\n", Y);
}
