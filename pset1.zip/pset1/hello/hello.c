#include <cs50.h> /*for run line 6*/
#include <stdio.h>

int main(void)
{
    string n = get_string("What is your name?\n");
    printf("hello, %s\n", n);
}