#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int a;
    do
    {
        // take my user input
        a = get_int("Height: ");
    }
    while (a < 1 || a > 8);

    // for hashs
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < a; j++)
        {
            if (i + j < a - 1)
            {
                printf(" ");
            }
            else
            {
                printf("#");
            }
        }
        // for new line
        printf("\n");
    }

}