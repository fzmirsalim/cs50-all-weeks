#include <cs50.h>
#include <stdio.h>

//Card Name is one of:                                      // Interp. name of credit card company
const string C_NAME_AMEX = "AMEX\n";
const string C_NAME_MASTERCARD = "MASTERCARD\n";
const string C_NAME_VISA = "VISA\n";
const string C_NAME_INVALID = "INVALID\n";                      // means credit card is invalid

//Card Length Standart is one of:                           // Interp. standart length of credit card numbers
const int C_LENGTH_AMEX = 15;
const int C_LENGTH_MASTC_OR_VISA = 16;                          // means length of Mastercard or Visa, used to check length
const int C_LENGTH_VISA = 13;

const int C_LENGTH_MAX = 16;                                    // Maximum length of credit card number

int c_num_to_array(long c_number, int *digits);
string get_name(int *digits, int c_length, int first_2);
int check_luhn(int *digits, int c_length);

//Output name of credit card
int main(void)
{
    // Get pos number from user
    long c_number;
    do
    {
        c_number = get_long("Number: ");
    }
    while (c_number < 1);
    int digits[C_LENGTH_MAX];
    int c_length = c_num_to_array(c_number, digits);             // Get length of c_number and convert c_number to array
    int first_2 = (10 * (digits[(c_length - 1)])) + digits[(c_length - 2)];
    string c_name = get_name(digits, c_length, first_2); // Check c_number for validity and produce credit card name
    printf("%s", c_name);
}

// Digits order in array is reversed relatively to card number
int c_num_to_array(long c_number, int *digits)
{
    int length_counter = 0;
    while (((c_number / 10) > 0) || ((c_number % 10) > 0))
    {
        *digits = (c_number % 10);                                // Put digit into current index in array
        c_number = (c_number / 10);
        length_counter++;
        digits++;                                                 // Increase pointer value to access the next index of array
    }
    return length_counter;
}

string get_name(int *digits, int c_length, int first_2)
{
    int result_luhn = check_luhn(digits, c_length);
    if ((c_length == C_LENGTH_AMEX) &&
        ((first_2 == 34) || (first_2 == 37)) &&
        (result_luhn == 0))
    {
        return C_NAME_AMEX;
    }
    else if ((c_length == C_LENGTH_MASTC_OR_VISA) &&
             ((first_2 >= 51) && (first_2 <= 55)) &&
             (result_luhn == 0))
    {
        return C_NAME_MASTERCARD;
    }
    else if (((c_length == C_LENGTH_VISA) || (c_length == C_LENGTH_MASTC_OR_VISA)) &&
             ((first_2 >= 40) && (first_2 <= 49)) &&
             (result_luhn == 0))
    {
        return C_NAME_VISA;
    }
    else
    {
        return C_NAME_INVALID;
    }
}

// Produce modulo of card digits sum using Luhn's algorithm
int check_luhn(int *digits, int c_length)
{
    int sf = 0;
    int sms = 0;
    int mn = 0;
    int n;
    for (int i = 0; i < c_length; i = i + 1)
    {
        n = *digits;
        if ((i % 2) ==
            1)
        {
            mn = 2 * n;
            if (mn > 9)
            {
                sms += (mn % 10) + (mn / 10);
            }
            else
            {
                sms += mn;
            }
        }
        else                                                 // Sum of every other digit, starting with the array's first digit
        {
            sf += n;
        }
        digits++;                                            // Increase pointer to provide access to the next item
    }
    int rl = (sf + sms) % 10;
    return rl;
}