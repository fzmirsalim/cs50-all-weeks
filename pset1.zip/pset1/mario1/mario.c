#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int a;
    do
    {
        // take my user input
        a = get_int("Height: ");
    }
    while (!(a >= 1 && a <= 8));
    // have to input between 1 and 8

    for (int c = 1; c <= a; c++)
    {

        // print space
        for (int b = 1; b <= a - c; b++)
        {
            printf(" ");
        }

        // print row number of times
        for (int d = 1; d <= c; d++)
        {
            printf("#");
        }

        printf(" ");
        printf(" ");


        //print row number of times
        for (int d = 1; d <= c; d++)
        {
            printf("#");
        }


        printf("\n");
    }

}