#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{
    float dol;
    do
    {
        // take my user input
        dol = get_float("Change owed: ");
    }
    while (dol < 0);

    int ce = round(dol * 100);

    int c = 0;

    while (ce != 0)
    {
        // 25
        c += ce / 25;
        ce = ce % 25;

        // 10 counts
        c += ce / 10;
        ce %= 10;

        // 5 counts
        c += ce / 5;
        ce %= 5;

        // 1 counts
        c += ce / 1;
        ce %= 1;
    }

    printf("%d\n", c);
}