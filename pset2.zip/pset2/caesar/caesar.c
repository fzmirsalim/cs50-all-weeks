#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    // chek if arguments is two
    if (argc != 2)
    {
        printf("can not be ciphered\n");
        return 1;
    }
    int a = atoi(argv[1]);
    if (a < 0)
    {
        printf("please enter a valid number\n");
        return 1;

    }

    // get user input
    string b = get_string("please Enter your text: ");

    printf("ciphertext:");

    for (int x = 0, c = strlen(b); x < c; x++)
    {
        // check char
        if (isalpha(b[x]))
        {
            // check let
            if (isupper(b[x]))
            {
                char d = ((b[x] - 65 + a) % 26) + 65;

                // print let
                printf("%c", d);

            }

            // check let this time for lowercase
            if (islower(b[x]))
            {
                char d = ((b[x] - 97 + a) % 26) + 97;

                // print let
                printf("%c", d);
            }
        }
        else
        {
            printf("%c", b[x]);
        }
    }
    printf("\n");
}