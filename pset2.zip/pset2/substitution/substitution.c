#include <cs50.h>
#include <stdio.h>
#include <string.h> // for strlen() مهم
#include <ctype.h>

int kk();
void ds();
void vaa(char pos, string key);

int main(int arg, string arv[])
{
    if (arg == 2)
    {
        if (strlen(arv[1]) == 26)
        {
            for (int x = 0; x < strlen(arv[1]) ; x++)
            {
                if (! isalpha(arv[1][x]))
                {
                    printf("Key must contain 26 characters.\n");
                    return 1;
                }

                for (int y = x + 1 ; y < strlen(arv[1]) ; y++)
                {
                    if (toupper(arv[1][y]) == toupper(arv[1][x]))
                    {
                        printf("Key must not contain repeated alphabets.\n");
                        return 1;
                    }
                }
            }
            ds(arv[1]);
        }
        else
        {
            printf("Key must contain 26 characters.\n");
            return 1;
        }
    }
    else
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }
    return 0;
}

void ds(string key)
{
    // get user input
    string a = get_string("plaintext: ");

    printf("ciphertext: ");

    for (int x = 0; x < strlen(a); x++)
    {
        if (isalpha(a[x]))
        {
            char b = a[x];
            if (islower(a[x]))
            {
                vaa(tolower(b), key);
            }
            else
            {
                vaa(toupper(b), key);
            }
        }
        else
        {
            printf("%c", a[x]);
        }
    }
    printf("\n");
}
void vaa(char o, string p)
{
    string d = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    for (int x = 0; x < strlen(d); x++)
    {
        if (islower(o))
        {
            if (o == tolower(d[x]))
            {
                printf("%c", tolower(p[x]));
            }
        }
        else
        {
            if (o == toupper(d[x]))
            {
                printf("%c", toupper(p[x]));
            }
        }
    }
}