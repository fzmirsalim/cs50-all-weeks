//library that we need
#include <cs50.h>    // library of cs50
#include <stdio.h>   // library for all c programs
#include <math.h>    // library for math
#include <string.h>  // library for string

int main()
{
    // take my user input
    string a = get_string("Text: ");
    int b = 0;
    int c = 1;
    int d = 0;

// here we count the words
    for (int x = 0; x < strlen(a); x++)
    {
        if ((a[x] >= 'a' && a[x] <= 'z') || (a[x] >= 'A' && a[x] <= 'Z'))
        {
            b++;
        }
        else if (a[x] == ' ')
        {
            c++;
        }
        else if (a[x] == '.' || a[x] == '!' || a[x] == '?')
        {
            d++;
        }
    }

    float e = 0.0588 * (100 * (float) b / (float) c) - 0.296 * (100 * (float)
              d /
              (float) c) - 15.8;
    // show output to user
    if (e < 16 && e >= 0)
    {
        printf("Grade %i\n", (int) round(e));
    }
    else if (e >= 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Before Grade 1\n");
    }
}